function fxn1(){
	document.getElementById('textbox').innerHTML = 
	"<b>More human twins are being born now than ever before. </b><br> <img src='images/fact1.jpg' alt='babe'>";
}

function fxn2(){
	document.getElementById('textbox').innerHTML = 
	"<b>A narwhal's tusk reveals its past living conditions.</b><br> <img src='images/fact2.jpg' alt='marine'>";
}

function fxn3(){
	document.getElementById('textbox').innerHTML = 
	"<b>The first person convicted of speeding was going eight mph. </b><br> <img src='images/fact3.jpg' alt='turttle'>";
}

function fxn4(){
	document.getElementById('textbox').innerHTML = 
	"<b>The world wastes about 1 billion metric tons of food each year. </b><br> <img src='images/fact4.jpg' alt='food waste'>";
}

function fxn5(){
	document.getElementById('textbox').innerHTML = 
	"<b>The severed head of a sea slug can grow a whole new body.</b><br> <img src='images/fact5.jpg' alt='sea slug'>";
}

function t1(){
	document.querySelector('body').style.backgroundImage = "";
	document.querySelector('body').style.backgroundColor = " #d1ffc6";
	document.querySelector('section').style.borderColor= " yellow";		
}

function t2(){
	document.querySelector('body').style.backgroundImage = "";
	document.querySelector('body').style.backgroundColor = "#aba361";
	document.querySelector('section').style.borderColor= " brown";	
}

function t3(){
	document.querySelector('body').style.backgroundImage = "url('images/beach.jpg')";
	document.querySelector('section').style.borderColor= " red";	
}


